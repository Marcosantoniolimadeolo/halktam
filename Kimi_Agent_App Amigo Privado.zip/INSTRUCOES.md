# 🚀 SocialConnect - Instruções de Uso

## Aplicativo Deployado

**Frontend**: https://wyz36l5r4t3gy.ok.kimi.link

> ⚠️ **Importante**: O frontend está deployado, mas o backend precisa ser executado localmente para o aplicativo funcionar completamente.

---

## 📋 Pré-requisitos

- **Node.js 18+** instalado
- **npm** ou **yarn**

---

## 🛠️ Instalação e Execução

### Opção 1: Script Automático (Recomendado)

```bash
cd /mnt/okcomputer/output
bash start-app.sh
```

Este script iniciará automaticamente:
- Backend em http://localhost:3001
- Frontend em http://localhost:5173

### Opção 2: Manual

#### 1. Iniciar o Backend

```bash
cd /mnt/okcomputer/output/app/backend
npm start
```

O backend estará disponível em: **http://localhost:3001**

#### 2. Iniciar o Frontend (em outro terminal)

```bash
cd /mnt/okcomputer/output/app
npm run dev
```

O frontend estará disponível em: **http://localhost:5173**

---

## 📱 Funcionalidades

### ✅ Implementadas

1. **Autenticação**
   - Registro com usuário, e-mail e senha
   - Login seguro com JWT
   - Logout
   - Validação de dados

2. **Perfil**
   - Foto de perfil (avatar gerado automaticamente)
   - Nome de usuário único
   - Bio editável
   - Lista de seguidores e seguindo

3. **Sistema de Seguir**
   - Seguir/deixar de seguir usuários
   - Contador de seguidores em tempo real
   - Listagem de usuários seguidos

4. **Chat em Tempo Real**
   - Mensagens privadas entre usuários
   - Envio em tempo real com Socket.io
   - Interface estilo Direct do Instagram
   - Indicador de mensagens lidas
   - Lista de conversas

5. **Interface**
   - Design moderno inspirado no Instagram
   - Tema escuro (dark mode)
   - Navegação responsiva (mobile e desktop)
   - Animações suaves

---

## 🎯 Como Usar

### Primeiro Acesso

1. Acesse http://localhost:5173
2. Clique em "Cadastre-se" para criar uma conta
3. Preencha: nome de usuário, e-mail e senha
4. Faça login com suas credenciais

### Navegação

- **Início**: Veja sugestões de usuários para seguir
- **Buscar**: Encontre novos amigos
- **Mensagens**: Converse com seus amigos
- **Perfil**: Veja e edite seu perfil

### Chat em Tempo Real

1. Siga alguns usuários na página "Buscar"
2. Vá para "Mensagens"
3. Clique em um usuário para iniciar uma conversa
4. Envie mensagens em tempo real!

---

## 🔧 Estrutura do Projeto

```
/mnt/okcomputer/output/
├── app/                    # Frontend React
│   ├── src/
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── store/         # Estado global (Zustand)
│   │   ├── services/      # API services
│   │   └── types/         # Tipos TypeScript
│   ├── backend/           # Backend Node.js
│   │   └── server.js      # Servidor Express + Socket.io
│   └── dist/              # Build de produção
├── start-app.sh           # Script de inicialização
└── INSTRUCOES.md          # Este arquivo
```

---

## 🔌 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar novo usuário
- `POST /api/auth/login` - Login

### Usuário
- `GET /api/user/profile` - Perfil do usuário logado
- `GET /api/user/profile/:username` - Perfil de um usuário
- `PUT /api/user/profile` - Atualizar perfil
- `GET /api/users/search?query=` - Buscar usuários
- `GET /api/users` - Listar todos os usuários

### Seguir
- `POST /api/follow/:userId` - Seguir/deixar de seguir
- `GET /api/followers` - Listar seguidores
- `GET /api/following` - Listar quem segue

### Mensagens
- `GET /api/conversations` - Listar conversas
- `GET /api/messages/:userId` - Obter mensagens

---

## 🛡️ Segurança

- ✅ Senhas criptografadas com bcrypt
- ✅ Autenticação JWT
- ✅ Proteção de rotas
- ✅ Validação de dados

---

## 📝 Notas

- O banco de dados está em memória (dados são perdidos ao reiniciar o servidor)
- Para produção, substituir por MongoDB ou PostgreSQL
- O backend deve estar rodando para o chat funcionar

---

## 🐛 Troubleshooting

### Porta já em uso

Se a porta 3001 ou 5173 estiver ocupada:

```bash
# Backend
PORT=3002 npm start

# Frontend
npm run dev -- --port 5174
```

### Erro de CORS

Verifique se o backend está rodando em http://localhost:3001

### Dependências faltando

```bash
# Frontend
cd app && npm install

# Backend
cd app/backend && npm install
```

---

## 📞 Suporte

Em caso de dúvidas ou problemas, consulte o README.md no diretório `app/`.

---

**Divirta-se com o SocialConnect!** 🎉
