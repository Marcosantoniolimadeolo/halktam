# SocialConnect

Um aplicativo de rede social inspirado no Instagram, com foco em uso privado entre amigos. Permite registro, login, seguir usuários e troca de mensagens em tempo real.

## Funcionalidades

### Autenticação
- Registro com usuário, e-mail e senha
- Login seguro com JWT
- Logout
- Validação de dados

### Perfil
- Foto de perfil
- Nome de usuário único
- Bio
- Lista de seguidores e seguindo

### Sistema de Seguir
- Seguir/deixar de seguir usuários
- Contador de seguidores
- Listagem de usuários seguidos

### Chat em Tempo Real
- Mensagens privadas entre usuários
- Envio em tempo real com Socket.io
- Interface estilo Direct do Instagram
- Indicador de mensagens lidas

### Interface
- Design moderno inspirado no Instagram
- Tema escuro (dark mode)
- Navegação responsiva (mobile e desktop)
- Animações suaves

## Tecnologias

### Frontend
- React 18
- TypeScript
- Tailwind CSS
- shadcn/ui
- Zustand (gerenciamento de estado)
- React Router
- Socket.io Client
- Axios

### Backend
- Node.js
- Express
- Socket.io
- JWT (autenticação)
- bcryptjs (criptografia)
- CORS

## Instalação

### Pré-requisitos
- Node.js 18+
- npm ou yarn

### 1. Clone o repositório
```bash
git clone <url-do-repositorio>
cd socialconnect
```

### 2. Instale as dependências do Frontend
```bash
cd app
npm install
```

### 3. Instale as dependências do Backend
```bash
cd backend
npm install
```

### 4. Configure as variáveis de ambiente
O backend já vem com um arquivo `.env` configurado:
```
JWT_SECRET=socialconnect_super_secret_key_2024
PORT=3001
```

### 5. Inicie o Backend
```bash
cd backend
npm start
```
O servidor estará rodando em `http://localhost:3001`

### 6. Inicie o Frontend
```bash
cd app
npm run dev
```
O aplicativo estará disponível em `http://localhost:5173`

## Estrutura do Projeto

```
app/
├── src/
│   ├── components/     # Componentes reutilizáveis
│   ├── pages/         # Páginas da aplicação
│   ├── store/         # Zustand stores
│   ├── services/      # API services
│   ├── types/         # TypeScript types
│   ├── App.tsx        # Componente principal
│   └── main.tsx       # Entry point
├── backend/
│   └── server.js      # Servidor Express + Socket.io
└── README.md
```

## Uso

1. **Registro**: Crie uma conta com nome de usuário, e-mail e senha
2. **Login**: Entre com seu e-mail e senha
3. **Buscar**: Encontre outros usuários na página de busca
4. **Seguir**: Clique em "Seguir" para começar a seguir alguém
5. **Mensagens**: Envie mensagens diretas para seus amigos
6. **Perfil**: Visualize e edite seu perfil

## API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar novo usuário
- `POST /api/auth/login` - Login

### Usuário
- `GET /api/user/profile` - Obter perfil do usuário logado
- `GET /api/user/profile/:username` - Obter perfil de um usuário
- `PUT /api/user/profile` - Atualizar perfil
- `GET /api/users/search?query=` - Buscar usuários
- `GET /api/users` - Listar todos os usuários

### Seguir
- `POST /api/follow/:userId` - Seguir/deixar de seguir
- `GET /api/followers` - Listar seguidores
- `GET /api/following` - Listar quem segue

### Mensagens
- `GET /api/conversations` - Listar conversas
- `GET /api/messages/:userId` - Obter mensagens com um usuário

## Eventos Socket.io

### Cliente -> Servidor
- `register` - Registrar usuário online
- `send_message` - Enviar mensagem
- `mark_read` - Marcar mensagem como lida
- `check_status` - Verificar status de usuário

### Servidor -> Cliente
- `new_message` - Nova mensagem recebida
- `message_sent` - Confirmação de mensagem enviada
- `user_status` - Status online/offline de usuário

## Segurança

- Senhas criptografadas com bcrypt
- Autenticação JWT
- Proteção de rotas
- Validação de dados

## Próximos Passos

- [ ] Upload de fotos de perfil
- [ ] Postagens com fotos
- [ ] Stories
- [ ] Curtidas e comentários
- [ ] Notificações push
- [ ] Banco de dados persistente (MongoDB)

## Licença

MIT

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues e pull requests.

---

Desenvolvido com ❤️ pela equipe SocialConnect
